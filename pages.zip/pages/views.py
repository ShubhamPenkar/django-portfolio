from django.shortcuts import render,HttpResponse,render


# Create your views here.
def home(request):
    return HttpResponse('hello young un')
def about(request):
    return render(request,'about.html')
def contact(request):
     return HttpResponse('9697-- do not contact me')




import psycopg2
from django.shortcuts import render
from django.http import HttpResponse

# PostgreSQL database connection
connection = psycopg2.connect(
    host="localhost",
    user="postgres",  # replace with your PostgreSQL username
    password="carrot@1234",
    database="pythondb1"
)
cursor = connection.cursor()

# SQL insert query
query = "INSERT INTO person (name, address, age) VALUES (%s, %s, %s)"

# View for homepage
def home_view(request):
    return render(request, "home.html")

# View to handle form result
def result(request):
    if request.method == "POST":
        name = request.POST.get('name')
        address = request.POST.get('address')
        age = request.POST.get('age')

        cursor.execute(query, [name, address, age])
        connection.commit()

        return render(request, 'home.html')
        return HttpResponse("Data Inserted Successfully!")
    return HttpResponse("Invalid Request")
