from django.contrib import admin
from django.urls import path,include
from pages import views

urlpatterns = [
    path('home/', views.home,name = 'home'),
    path('about/',views.about, name = 'about'),
    path('contact/', views.contact, name = 'contact'),
    path('go',views.result,name='view page'),
]
